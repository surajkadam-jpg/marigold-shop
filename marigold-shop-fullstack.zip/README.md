# Marigold Shop Fullstack

Fullstack online flower shop ready for deployment.